package com.craftiv.templateservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TemplateServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
